{{/*
Control Plane Helm Chart - Helper Templates
Uses graph-olap-common library for standard templates.
*/}}

{{/*
Expand the name of the chart.
Wraps common.names.name for chart-specific reference.
*/}}
{{- define "control-plane.name" -}}
{{- include "common.names.name" . }}
{{- end }}

{{/*
Create a default fully qualified app name.
Wraps common.names.fullname for chart-specific reference.
*/}}
{{- define "control-plane.fullname" -}}
{{- include "common.names.fullname" . }}
{{- end }}

{{/*
Create chart name and version as used by the chart label.
Wraps common.names.chart for chart-specific reference.
*/}}
{{- define "control-plane.chart" -}}
{{- include "common.names.chart" . }}
{{- end }}

{{/*
Common labels - uses common library with extensions.
*/}}
{{- define "control-plane.labels" -}}
{{ include "common.labels.standard" . }}
app: control-plane
{{- end }}

{{/*
Selector labels - uses common library matchLabels.
*/}}
{{- define "control-plane.selectorLabels" -}}
{{ include "common.labels.matchLabels" . }}
app: control-plane
{{- end }}

{{/*
Create the name of the service account to use.
Wraps common.names.serviceAccountName for chart-specific reference.
*/}}
{{- define "control-plane.serviceAccountName" -}}
{{- include "common.names.serviceAccountName" . }}
{{- end }}

{{/*
Pod annotations including Prometheus metrics.
*/}}
{{- define "control-plane.podAnnotations" -}}
{{ include "common.annotations.pod" . }}
{{- end }}

{{/*
Pod security context.
*/}}
{{- define "control-plane.podSecurityContext" -}}
{{ include "common.security.podSecurityContext" . }}
{{- end }}

{{/*
Container security context.
*/}}
{{- define "control-plane.containerSecurityContext" -}}
{{ include "common.security.containerSecurityContext" . }}
{{- end }}
